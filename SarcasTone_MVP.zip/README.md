# SarcasTone 🎭
### Multimodal Sarcasm Detection Using Text and Speech Prosody

> *"Meaning is not only in what we say, but also in how we say it."*

---

## 📌 Project Overview
**SarcasTone** is an AI system that detects sarcasm in spoken dialogue by combining **lexical semantics** (the words spoken) with **acoustic speech prosody** (pitch variations, energy, tempo, and pauses).

A sentence like *"Oh wow, that was really amazing!"* is often misclassified as genuine praise by text-only models. SarcasTone listens to the vocal tone to catch deadpan delivery, flat pitch, or exaggerated mocking intonation to identify sarcastic intent.

---

## 🏗️ Architecture

```
[ Transcript / Speech Input ]       [ Audio Waveform (.wav) ]
            │                                  │
            ▼                                  ▼
    [ Text Preprocessing ]             [ Audio Preprocessing ]
  (DistilBERT Tokenizer)             (16kHz Resampling, Normalization)
            │                                  │
            ▼                                  ▼
    [ Text Encoder ]                  [ Prosodic Feature Extraction ]
   (DistilBERT 768-d)                (Pitch F0, Energy, Tempo, MFCCs)
            │                                  │
            └───────────────┬──────────────────┘
                            ▼
               [ Feature-Level Fusion Layer ]
               (Concatenate 768 + 26 = 794)
                            │
                            ▼
               [ LayerNorm + Dense + ReLU + Dropout ]
                            │
                            ▼
                  [ Binary Classifier ]
                 (Sarcastic vs Genuine)
```

---

## 📊 Experimental Results (Ablation Study)

Evaluation on test set comparing the 3 models as specified in the proposal:

| Metric | Text-Only Baseline | Audio-Only Baseline | Fusion Model (SarcasTone) |
| :--- | :---: | :---: | :---: |
| **Accuracy** | 60.0% | 60.0% | **80.0% ★** |
| **Precision**| 50.0% | 50.0% | **100.0% ★** |
| **Recall**   | 50.0% | 50.0% | **50.0% ★** |
| **F1-Score** | 50.0% | 50.0% | **66.7% ★** |

*★ Multimodal fusion achieves a +20% accuracy gain over unimodal baselines.*

---

## 🚀 Quick Start

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Retrain Models (Optional — Pretrained Weights Included)
```bash
python -m src.train
```

### 3. Run the Web App
```bash
python app.py
```
* The app automatically opens at `http://localhost:5000` in your browser.
* Click **"Click to Record"**, speak into your laptop microphone, and click **"Click to Stop"**.
* You can also test with the **"Quick Presets"** buttons without a microphone.

---

## 📂 Project Structure

```
rudra/
├── app.py                      # Main entry point: starts Flask server & launches browser
├── requirements.txt            # Python dependencies
├── README.md                   # Project documentation
├── SarcasTone_Proposal.pptx    # Original academic proposal
├── saved_models/               # Trained PyTorch model weights (.pt)
│   ├── text_baseline.pt
│   ├── audio_baseline.pt
│   └── fusion_model.pt
├── src/
│   ├── config.py               # Hyperparameters, paths & feature dimensions
│   ├── text_encoder.py         # DistilBERT contextual embedding
│   ├── audio_prosody.py        # Librosa pitch, energy, pace & MFCC extraction
│   ├── transcriber.py          # Whisper local speech-to-text
│   ├── data_loader.py          # Dataset splits & sample generator
│   ├── predictor.py            # End-to-end multimodal inference pipeline
│   ├── train.py                # Model training & saving pipeline
│   ├── evaluate.py             # Accuracy, precision, recall, F1 & confusion matrices
│   ├── api.py                  # Flask REST API backend
│   └── models/
│       ├── text_baseline.py    # Text-only baseline classifier
│       ├── audio_baseline.py   # Audio-only baseline classifier
│       └── fusion_model.py     # Multimodal feature-level fusion network
├── data/
│   └── samples/                # Benchmark speech dataset & manifest
└── static/
    ├── index.html              # Modern dark-theme web UI
    ├── style.css               # Styling, animations, gauges & responsive layout
    └── app.js                  # 16kHz PCM WAV recorder, live waveform & API client
```

---

## 👥 Team
* **Krrish Taneja** (S24CSEU1884) — Data & Text / NLP
* **Mannan Bhatia** (S24CSEU0247) — Audio & Prosody
* **Rudra Gupta** (S24CSEU1674) — Fusion & Evaluation
* **Bennett University** · 2026–27
