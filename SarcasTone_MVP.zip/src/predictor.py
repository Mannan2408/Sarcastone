"""
SarcasTone — Single Prediction Pipeline
==========================================
End-to-end inference: audio → transcription + emoji analysis →
text embedding → audio features + pitch contour →
run all 3 models + semantic-acoustic conflict scoring → return structured analysis.
"""

import os
import torch
import numpy as np
import librosa

from src.config import MODEL_DIR, SAMPLE_RATE, TEXT_EMBEDDING_DIM, AUDIO_FEATURE_DIM
from src.text_encoder import get_text_encoder
from src.audio_prosody import extract_prosody, describe_prosody, extract_pitch_contour
from src.transcriber import get_transcriber
from src.emoji_analyzer import analyze_emojis
from src.models.text_baseline import TextBaseline
from src.models.audio_baseline import AudioBaseline
from src.models.fusion_model import FusionModel


class Predictor:
    """Complete multimodal sarcasm detection pipeline with explainability."""

    def __init__(self):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.text_encoder = get_text_encoder()
        self.transcriber = get_transcriber()

        # Load trained models
        self.text_model = self._load_model(TextBaseline(), "text_baseline.pt")
        self.audio_model = self._load_model(AudioBaseline(), "audio_baseline.pt")
        self.fusion_model = self._load_model(FusionModel(), "fusion_model.pt")

        print("[Predictor] All models loaded. Ready for inference.")

    def _load_model(self, model, filename):
        """Load model weights if available, otherwise use untrained model."""
        path = os.path.join(MODEL_DIR, filename)
        if os.path.exists(path):
            model.load_state_dict(torch.load(path, map_location=self.device, weights_only=True))
            print(f"  ✓ Loaded {filename}")
        else:
            print(f"  ⚠️  {filename} not found — using untrained model.")
        model.to(self.device)
        model.eval()
        return model

    def predict(self, audio_path: str = None, audio_array: np.ndarray = None,
                sr: int = SAMPLE_RATE, text_override: str = None) -> dict:
        """
        Run full sarcasm detection pipeline with emoji & pitch contour analysis.

        Args:
            audio_path: Path to .wav file.
            audio_array: Raw audio numpy array.
            sr: Sample rate.
            text_override: If provided, skip transcription and use this text.

        Returns:
            Dict with transcription, predictions, confidence scores,
            emoji semantics, pitch contour series, and conflict meter.
        """
        # Step 1: Load audio
        if audio_array is not None:
            y = audio_array.astype(np.float32)
        elif audio_path is not None:
            y, sr = librosa.load(audio_path, sr=SAMPLE_RATE)
        else:
            raise ValueError("Either audio_path or audio_array must be provided")

        # Step 2: Transcribe or use override
        if text_override:
            transcription = text_override
        else:
            transcription = self.transcriber.transcribe(audio_array=y, sr=sr)

        # Step 3: Emoji Semantic Analysis
        emoji_info = analyze_emojis(transcription)

        # Use augmented text (where emojis are expanded to semantic tokens) for embedding
        text_for_embedding = emoji_info["augmented_text"] if emoji_info["has_emojis"] else transcription
        text_embedding = self.text_encoder.encode(text_for_embedding)

        # Step 4: Extract audio features & pitch contour curve
        audio_features = extract_prosody(y=y, sr=sr)
        pitch_contour = extract_pitch_contour(y=y, sr=sr, num_points=60)
        prosody_description = describe_prosody(audio_features, pitch_contour)

        # Step 5: Run all 3 models
        text_emb_tensor = text_embedding.unsqueeze(0).to(self.device)
        audio_feat_tensor = torch.tensor(audio_features, dtype=torch.float32).unsqueeze(0).to(self.device)

        with torch.no_grad():
            text_logit = self.text_model(text_emb_tensor)
            audio_logit = self.audio_model(audio_feat_tensor)
            fusion_logit = self.fusion_model(text_emb_tensor, audio_feat_tensor)

            text_prob = torch.sigmoid(text_logit).item()
            audio_prob = torch.sigmoid(audio_logit).item()
            fusion_prob = torch.sigmoid(fusion_logit).item()

        # Emoji Modulation: If heavy sarcasm emojis present (e.g. 🙃, 🙄, 🤡), modulate probability
        if emoji_info["has_emojis"]:
            emoji_weight = emoji_info["sarcasm_bias"]
            # Blend model output with emoji signal (65% model, 35% explicit emoji indicator)
            fusion_prob = (fusion_prob * 0.65) + (emoji_weight * 0.35)
            text_prob = (text_prob * 0.60) + (emoji_weight * 0.40)

        # Step 6: Semantic-Acoustic Conflict Index Calculation (Idea 1)
        # Pitch flatness: low std = flat/deadpan
        pitch_std = float(prosody_description["pitch_std_hz"])
        is_pitch_flat = pitch_std < 25.0

        # Lexical tone estimation
        # If words/emojis are positive or sarcastic, but pitch is flat, conflict is high
        if emoji_info["has_emojis"] and emoji_info["sarcasm_bias"] > 0.6:
            conflict_index = 80.0 + (15.0 if is_pitch_flat else 5.0)
            conflict_detail = "High discrepancy: Sarcasm-bearing emojis (e.g. upside-down/eye-roll) paired with acoustic delivery."
        elif is_pitch_flat and text_prob < 0.45:
            # Positive words with flat deadpan voice = textbook sarcasm discrepancy
            conflict_index = 85.0 + min(12.0, (0.5 - text_prob) * 30.0)
            conflict_detail = "Severe discrepancy: Affirmative lexical semantics delivered with monotone/flat vocal pitch."
        elif not is_pitch_flat and text_prob < 0.45:
            # Positive words with dynamic pitch = genuine praise
            conflict_index = max(10.0, 30.0 - (pitch_std * 0.2))
            conflict_detail = "Low discrepancy: Positive words match dynamic, expressive pitch modulation."
        else:
            conflict_index = round(abs(text_prob - audio_prob) * 100, 1)
            conflict_detail = "Cross-modal divergence between text sentiment branch and acoustic prosody branch."

        conflict_index = round(min(98.5, max(5.0, conflict_index)), 1)

        # Step 7: Build final structured response
        is_sarcastic = fusion_prob >= 0.50
        result = {
            "transcription": transcription,
            "prediction": {
                "label": "SARCASTIC" if is_sarcastic else "NON-SARCASTIC",
                "confidence": round(fusion_prob * 100 if is_sarcastic else (1 - fusion_prob) * 100, 1),
                "sarcasm_probability": round(fusion_prob * 100, 1),
            },
            "model_comparison": {
                "text_only": {
                    "label": "SARCASTIC" if text_prob >= 0.5 else "NON-SARCASTIC",
                    "confidence": round(max(text_prob, 1 - text_prob) * 100, 1),
                    "sarcasm_probability": round(text_prob * 100, 1),
                },
                "audio_only": {
                    "label": "SARCASTIC" if audio_prob >= 0.5 else "NON-SARCASTIC",
                    "confidence": round(max(audio_prob, 1 - audio_prob) * 100, 1),
                    "sarcasm_probability": round(audio_prob * 100, 1),
                },
                "fusion": {
                    "label": "SARCASTIC" if is_sarcastic else "NON-SARCASTIC",
                    "confidence": round(max(fusion_prob, 1 - fusion_prob) * 100, 1),
                    "sarcasm_probability": round(fusion_prob * 100, 1),
                },
            },
            "audio_analysis": prosody_description,
            "pitch_contour": pitch_contour,
            "conflict_analysis": {
                "conflict_index": conflict_index,
                "conflict_level": "CRITICAL" if conflict_index > 75 else ("MODERATE" if conflict_index > 40 else "HARMONIC"),
                "detail": conflict_detail,
                "pitch_std_hz": round(pitch_std, 1),
                "is_pitch_flat": is_pitch_flat,
            },
            "emoji_analysis": emoji_info,
        }

        return result


# Singleton
_predictor_instance = None


def get_predictor() -> Predictor:
    global _predictor_instance
    if _predictor_instance is None:
        _predictor_instance = Predictor()
    return _predictor_instance
