/**
 * SarcasTone — Multimodal Sarcasm Detection Lab
 * Frontend Controller & Smart VAD Audio Intelligence Engine
 */

// ===== DOM Elements =====
const recordBtn = document.getElementById("recordBtn");
const fileUpload = document.getElementById("fileUpload");
const recordTimer = document.getElementById("recordTimer");
const recordingBadge = document.getElementById("recordingBadge");
const recStatusText = document.getElementById("recStatusText");
const waveformCanvas = document.getElementById("waveformCanvas");
const visualizerOverlay = document.getElementById("visualizerOverlay");
const loadingSection = document.getElementById("loadingSection");
const resultsSection = document.getElementById("resultsSection");
const resetBtn = document.getElementById("resetBtn");
const systemStatus = document.getElementById("systemStatus");

// VAD Elements
const vadLevel = document.getElementById("vadLevel");
const vadStatus = document.getElementById("vadStatus");

// Verdict Elements
const verdictBanner = document.getElementById("verdictBanner");
const verdictTag = document.getElementById("verdictTag");
const verdictLabel = document.getElementById("verdictLabel");
const verdictStatement = document.getElementById("verdictStatement");
const sarcasmProb = document.getElementById("sarcasmProb");
const confidenceValue = document.getElementById("confidenceValue");

// Conflict / Explainability Elements
const conflictChip = document.getElementById("conflictChip");
const conflictMeter = document.getElementById("conflictMeter");
const conflictScore = document.getElementById("conflictScore");
const conflictDetail = document.getElementById("conflictDetail");
const emojiRecognitionBar = document.getElementById("emojiRecognitionBar");
const emojiTags = document.getElementById("emojiTags");

// Transcript Sandbox Elements
const transcriptInput = document.getElementById("transcriptInput");
const reevaluateBtn = document.getElementById("reevaluateBtn");

// Pitch Track Canvas
const pitchContourCanvas = document.getElementById("pitchContourCanvas");
const pitchCanvasCtx = pitchContourCanvas.getContext("2d");

// Telemetry Elements
const pitchBadge = document.getElementById("pitchBadge");
const pitchValue = document.getElementById("pitchValue");
const pitchDetail = document.getElementById("pitchDetail");

const energyBadge = document.getElementById("energyBadge");
const energyValue = document.getElementById("energyValue");
const energyDetail = document.getElementById("energyDetail");

const paceBadge = document.getElementById("paceBadge");
const tempoValue = document.getElementById("tempoValue");
const paceDetail = document.getElementById("paceDetail");

// Ablation Elements
const textMeter = document.getElementById("textMeter");
const textScore = document.getElementById("textScore");
const textChip = document.getElementById("textChip");

const audioMeter = document.getElementById("audioMeter");
const audioScore = document.getElementById("audioScore");
const audioChip = document.getElementById("audioChip");

const fusionMeter = document.getElementById("fusionMeter");
const fusionScore = document.getElementById("fusionScore");
const fusionChip = document.getElementById("fusionChip");

// ===== State =====
let isRecording = false;
let timerInterval = null;
let recordingStartTime = 0;
let audioContext = null;
let analyser = null;
let scriptProcessor = null;
let mediaStream = null;
let pcmBuffers = [];
let animationId = null;

// Smart VAD Constants & State
const SPEECH_RMS_THRESHOLD = 0.025;   // Above this = speech detected
const SILENCE_RMS_THRESHOLD = 0.015;  // Below this = silence / break
const AUTO_STOP_SILENCE_MS = 1600;    // Continuous silence duration to auto-complete
let hasSpoken = false;
let silenceStartTime = null;

// ===== Precision Oscilloscope Visualizer =====
const canvasCtx = waveformCanvas.getContext("2d");

function setupCanvases() {
    const dpr = window.devicePixelRatio || 1;

    // Oscilloscope setup
    const rect = waveformCanvas.getBoundingClientRect();
    waveformCanvas.width = rect.width * dpr;
    waveformCanvas.height = rect.height * dpr;
    canvasCtx.scale(dpr, dpr);
    drawIdleGrid();

    // Pitch contour setup
    const pRect = pitchContourCanvas.getBoundingClientRect();
    pitchContourCanvas.width = pRect.width * dpr;
    pitchContourCanvas.height = pRect.height * dpr;
    pitchCanvasCtx.scale(dpr, dpr);
    drawIdlePitchGrid();
}

function drawIdleGrid() {
    const w = waveformCanvas.getBoundingClientRect().width;
    const h = waveformCanvas.getBoundingClientRect().height;

    canvasCtx.clearRect(0, 0, w, h);
    canvasCtx.strokeStyle = "rgba(255, 255, 255, 0.04)";
    canvasCtx.lineWidth = 1;

    for (let y = 0; y <= h; y += 25) {
        canvasCtx.beginPath();
        canvasCtx.moveTo(0, y);
        canvasCtx.lineTo(w, y);
        canvasCtx.stroke();
    }

    canvasCtx.strokeStyle = "rgba(56, 189, 248, 0.2)";
    canvasCtx.lineWidth = 1;
    canvasCtx.beginPath();
    canvasCtx.moveTo(0, h / 2);
    canvasCtx.lineTo(w, h / 2);
    canvasCtx.stroke();
}

function drawLiveOscilloscope() {
    if (!analyser) return;

    const bufferLength = analyser.fftSize;
    const dataArray = new Float32Array(bufferLength);
    analyser.getFloatTimeDomainData(dataArray);

    const w = waveformCanvas.getBoundingClientRect().width;
    const h = waveformCanvas.getBoundingClientRect().height;

    canvasCtx.clearRect(0, 0, w, h);

    // Background grid
    canvasCtx.strokeStyle = "rgba(255, 255, 255, 0.04)";
    canvasCtx.lineWidth = 1;
    for (let y = 0; y <= h; y += 25) {
        canvasCtx.beginPath();
        canvasCtx.moveTo(0, y);
        canvasCtx.lineTo(w, y);
        canvasCtx.stroke();
    }

    // Trace
    canvasCtx.lineWidth = 2;
    canvasCtx.strokeStyle = "#38bdf8";
    canvasCtx.shadowColor = "#38bdf8";
    canvasCtx.shadowBlur = 8;
    canvasCtx.beginPath();

    const sliceWidth = w / bufferLength;
    let x = 0;

    for (let i = 0; i < bufferLength; i++) {
        const v = dataArray[i];
        const y = (v * (h * 0.45)) + (h / 2);
        if (i === 0) canvasCtx.moveTo(x, y);
        else canvasCtx.lineTo(x, y);
        x += sliceWidth;
    }

    canvasCtx.stroke();
    canvasCtx.shadowBlur = 0;

    // --- Smart VAD Level & Break Detection ---
    let sumSquares = 0;
    for (let i = 0; i < bufferLength; i++) {
        sumSquares += dataArray[i] * dataArray[i];
    }
    const currentRMS = Math.sqrt(sumSquares / bufferLength);

    // Update VAD meter width (scaled 0 to 100%)
    const levelPct = Math.min(100, Math.round(currentRMS * 450));
    vadLevel.style.width = `${levelPct}%`;

    const now = Date.now();

    if (currentRMS >= SPEECH_RMS_THRESHOLD) {
        hasSpoken = true;
        silenceStartTime = null;
        vadLevel.className = "vad-level active";
        vadStatus.textContent = "Speaking detected (listening...)";
        vadStatus.className = "vad-status speaking";
        recStatusText.textContent = "SPEAKING ACTIVE";
    } else if (hasSpoken && currentRMS < SILENCE_RMS_THRESHOLD) {
        vadLevel.className = "vad-level";
        if (!silenceStartTime) {
            silenceStartTime = now;
        }

        const elapsedSilence = now - silenceStartTime;
        const remaining = Math.max(0, ((AUTO_STOP_SILENCE_MS - elapsedSilence) / 1000)).toFixed(1);

        if (elapsedSilence >= AUTO_STOP_SILENCE_MS) {
            vadStatus.textContent = "Pause complete · Auto-analyzing...";
            vadStatus.className = "vad-status";
            stopRecording();
            return;
        } else {
            vadStatus.textContent = `Break detected · Auto-finishing in ${remaining}s...`;
            vadStatus.className = "vad-status pausing";
            recStatusText.textContent = "BREAK DETECTED";
        }
    } else {
        vadLevel.className = "vad-level";
        if (!hasSpoken) {
            vadStatus.textContent = "Listening for speech...";
            vadStatus.className = "vad-status";
            recStatusText.textContent = "WAITING FOR VOICE";
        }
    }

    animationId = requestAnimationFrame(drawLiveOscilloscope);
}

// ===== Pitch Track (F0 Contour) Graph Renderer (Idea 2) =====
function drawIdlePitchGrid() {
    const w = pitchContourCanvas.getBoundingClientRect().width;
    const h = pitchContourCanvas.getBoundingClientRect().height;

    pitchCanvasCtx.clearRect(0, 0, w, h);
    pitchCanvasCtx.strokeStyle = "rgba(255, 255, 255, 0.05)";
    pitchCanvasCtx.lineWidth = 1;

    for (let y = 0; y <= h; y += 25) {
        pitchCanvasCtx.beginPath();
        pitchCanvasCtx.moveTo(0, y);
        pitchCanvasCtx.lineTo(w, y);
        pitchCanvasCtx.stroke();
    }
}

function drawPitchContour(contour, isPitchFlat) {
    if (!contour || contour.length === 0) return;

    const w = pitchContourCanvas.getBoundingClientRect().width;
    const h = pitchContourCanvas.getBoundingClientRect().height;

    pitchCanvasCtx.clearRect(0, 0, w, h);

    // Background grid & Hz labels
    pitchCanvasCtx.strokeStyle = "rgba(255, 255, 255, 0.05)";
    pitchCanvasCtx.fillStyle = "#64748b";
    pitchCanvasCtx.font = "10px JetBrains Mono";

    const hzLevels = [100, 150, 200, 250, 300];
    const minHz = 75;
    const maxHz = 325;

    for (const hz of hzLevels) {
        const y = h - ((hz - minHz) / (maxHz - minHz)) * h;
        pitchCanvasCtx.beginPath();
        pitchCanvasCtx.moveTo(35, y);
        pitchCanvasCtx.lineTo(w, y);
        pitchCanvasCtx.stroke();
        pitchCanvasCtx.fillText(`${hz}Hz`, 4, y + 3);
    }

    // Plot F0 points
    const paddingLeft = 40;
    const plotWidth = w - paddingLeft - 10;
    const strokeColor = isPitchFlat ? "#f43f5e" : "#38bdf8";

    pitchCanvasCtx.lineWidth = 2.5;
    pitchCanvasCtx.strokeStyle = strokeColor;
    pitchCanvasCtx.shadowColor = strokeColor;
    pitchCanvasCtx.shadowBlur = 6;
    pitchCanvasCtx.beginPath();

    let started = false;
    for (let i = 0; i < contour.length; i++) {
        const p = contour[i];
        if (p.voiced && p.hz > 50) {
            const x = paddingLeft + (i / (contour.length - 1)) * plotWidth;
            const clampedHz = Math.max(minHz, Math.min(maxHz, p.hz));
            const y = h - ((clampedHz - minHz) / (maxHz - minHz)) * h;

            if (!started) {
                pitchCanvasCtx.moveTo(x, y);
                started = true;
            } else {
                pitchCanvasCtx.lineTo(x, y);
            }
        }
    }

    pitchCanvasCtx.stroke();
    pitchCanvasCtx.shadowBlur = 0;

    // Draw individual pitch sample dots
    for (let i = 0; i < contour.length; i++) {
        const p = contour[i];
        if (p.voiced && p.hz > 50) {
            const x = paddingLeft + (i / (contour.length - 1)) * plotWidth;
            const clampedHz = Math.max(minHz, Math.min(maxHz, p.hz));
            const y = h - ((clampedHz - minHz) / (maxHz - minHz)) * h;

            pitchCanvasCtx.fillStyle = strokeColor;
            pitchCanvasCtx.beginPath();
            pitchCanvasCtx.arc(x, y, 3, 0, Math.PI * 2);
            pitchCanvasCtx.fill();
        }
    }
}

// ===== 16kHz PCM WAV Encoder =====
function encodeWAV(buffers, sampleRate) {
    let totalLength = buffers.reduce((acc, b) => acc + b.length, 0);
    let samples = new Float32Array(totalLength);
    let offset = 0;
    for (let b of buffers) {
        samples.set(b, offset);
        offset += b.length;
    }

    const targetRate = 16000;
    const resampled = (sampleRate === targetRate) ? samples : resampleAudio(samples, sampleRate, targetRate);

    const buffer = new ArrayBuffer(44 + resampled.length * 2);
    const view = new DataView(buffer);

    function writeString(view, offset, str) {
        for (let i = 0; i < str.length; i++) {
            view.setUint8(offset + i, str.charCodeAt(i));
        }
    }

    writeString(view, 0, 'RIFF');
    view.setUint32(4, 36 + resampled.length * 2, true);
    writeString(view, 8, 'WAVE');
    writeString(view, 12, 'fmt ');
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true);              // PCM
    view.setUint16(22, 1, true);              // Mono
    view.setUint32(24, targetRate, true);      // 16kHz
    view.setUint32(28, targetRate * 2, true);  // Byte rate
    view.setUint16(32, 2, true);              // Block align
    view.setUint16(34, 16, true);             // 16-bit
    writeString(view, 36, 'data');
    view.setUint32(40, resampled.length * 2, true);

    let pcmOffset = 44;
    for (let i = 0; i < resampled.length; i++, pcmOffset += 2) {
        let s = Math.max(-1, Math.min(1, resampled[i]));
        view.setInt16(pcmOffset, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
    }

    return new Blob([buffer], { type: 'audio/wav' });
}

function resampleAudio(audioBuffer, fromSampleRate, toSampleRate) {
    if (fromSampleRate === toSampleRate) return audioBuffer;
    const compression = fromSampleRate / toSampleRate;
    const length = Math.round(audioBuffer.length / compression);
    const result = new Float32Array(length);
    for (let i = 0; i < length; i++) {
        const index = Math.round(i * compression);
        result[i] = audioBuffer[index] || 0;
    }
    return result;
}

// ===== Acquisition Lifecycle =====
async function startRecording() {
    try {
        mediaStream = await navigator.mediaDevices.getUserMedia({
            audio: {
                channelCount: 1,
                echoCancellation: true,
                noiseSuppression: true,
            }
        });

        audioContext = new (window.AudioContext || window.webkitAudioContext)();
        const source = audioContext.createMediaStreamSource(mediaStream);

        analyser = audioContext.createAnalyser();
        analyser.fftSize = 2048;
        source.connect(analyser);

        scriptProcessor = audioContext.createScriptProcessor(4096, 1, 1);
        pcmBuffers = [];
        scriptProcessor.onaudioprocess = (e) => {
            if (!isRecording) return;
            const input = e.inputBuffer.getChannelData(0);
            pcmBuffers.push(new Float32Array(input));
        };

        source.connect(scriptProcessor);
        scriptProcessor.connect(audioContext.destination);

        isRecording = true;
        hasSpoken = false;
        silenceStartTime = null;

        // UI Updates
        recordBtn.classList.add("recording");
        recordBtn.querySelector(".btn-text").textContent = "Halt Stream";
        recordBtn.querySelector(".btn-icon").textContent = "■";

        systemStatus.classList.add("recording");
        systemStatus.querySelector(".status-text").textContent = "SMART LISTENING";

        recordingBadge.classList.remove("hidden");
        visualizerOverlay.classList.add("active");

        recordingStartTime = Date.now();
        startTimer();

        drawLiveOscilloscope();

    } catch (err) {
        console.error("Microphone access fault:", err);
        alert("Microphone permission required for audio streaming. Please grant access in your browser or select a Test Benchmark.");
    }
}

function stopRecording() {
    if (!isRecording) return;
    isRecording = false;
    stopTimer();

    recordBtn.classList.remove("recording");
    recordBtn.querySelector(".btn-text").textContent = "Smart Record";
    recordBtn.querySelector(".btn-icon").textContent = "●";

    systemStatus.classList.remove("recording");
    systemStatus.querySelector(".status-text").textContent = "PROCESSING...";

    recordingBadge.classList.add("hidden");
    visualizerOverlay.classList.remove("active");
    vadLevel.style.width = "0%";
    vadStatus.textContent = "Stream halted · Ingesting tensor...";

    if (animationId) {
        cancelAnimationFrame(animationId);
        animationId = null;
    }
    drawIdleGrid();

    const sampleRate = audioContext ? audioContext.sampleRate : 16000;
    const wavBlob = encodeWAV(pcmBuffers, sampleRate);

    if (mediaStream) {
        mediaStream.getTracks().forEach(t => t.stop());
        mediaStream = null;
    }
    if (scriptProcessor) {
        scriptProcessor.disconnect();
        scriptProcessor = null;
    }
    if (audioContext) {
        audioContext.close();
        audioContext = null;
    }

    sendAudioForInference(wavBlob);
}

function startTimer() {
    timerInterval = setInterval(() => {
        const elapsed = Math.floor((Date.now() - recordingStartTime) / 1000);
        const mins = Math.floor(elapsed / 60);
        const secs = elapsed % 60;
        recordTimer.textContent = `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
    }, 1000);
}

function stopTimer() {
    if (timerInterval) {
        clearInterval(timerInterval);
        timerInterval = null;
    }
    recordTimer.textContent = "00:00";
}

// ===== Inference Client =====
async function sendAudioForInference(audioBlob) {
    loadingSection.classList.remove("hidden");
    resultsSection.classList.add("hidden");
    recordBtn.disabled = true;

    try {
        const formData = new FormData();
        formData.append("audio", audioBlob, "input_stream.wav");

        const resp = await fetch("/api/analyze", {
            method: "POST",
            body: formData,
        });

        if (!resp.ok) {
            const err = await resp.json();
            throw new Error(err.error || "Inference pipeline fault");
        }

        const data = await resp.json();
        renderAnalysis(data);

    } catch (err) {
        console.error("Pipeline failure:", err);
        alert(`Analysis Error: ${err.message}`);
    } finally {
        loadingSection.classList.add("hidden");
        recordBtn.disabled = false;
        systemStatus.querySelector(".status-text").textContent = "SYSTEM READY";
    }
}

// ===== Results Renderer =====
function renderAnalysis(data) {
    resultsSection.classList.remove("hidden");

    // Decoded Transcript Sandbox
    transcriptInput.value = data.transcription;

    // Sarcasm Classification Banner
    const isSarcastic = data.prediction.label === "SARCASTIC";
    verdictBanner.className = `verdict-banner ${isSarcastic ? "sarcastic" : "genuine"}`;
    verdictLabel.textContent = isSarcastic ? "SARCASTIC" : "GENUINE / NON-SARCASTIC";
    verdictTag.textContent = isSarcastic ? "ALERT // SARCASM DETECTED" : "CLASSIFICATION // NON-SARCASTIC";

    verdictStatement.textContent = isSarcastic
        ? "Prosodic delivery (pitch contour & energy distribution) conflicts with literal lexical sentiment."
        : "Vocal acoustics harmonize with semantic meaning; genuine conversational tone identified.";

    sarcasmProb.textContent = `${data.prediction.sarcasm_probability}%`;
    confidenceValue.textContent = `${data.prediction.confidence}%`;

    // Explainable AI: Semantic-Acoustic Conflict Meter (Idea 1)
    const conf = data.conflict_analysis;
    if (conf) {
        conflictScore.textContent = `${conf.conflict_index}%`;
        conflictDetail.textContent = conf.detail;
        conflictChip.textContent = `${conf.conflict_level} CONFLICT`;

        if (conf.conflict_level === "CRITICAL") {
            conflictChip.className = "conflict-chip";
        } else if (conf.conflict_level === "MODERATE") {
            conflictChip.className = "conflict-chip moderate";
        } else {
            conflictChip.className = "conflict-chip harmonic";
        }

        setTimeout(() => {
            conflictMeter.style.width = `${conf.conflict_index}%`;
        }, 150);
    }

    // Emoji Recognition Bar
    const emojiInfo = data.emoji_analysis;
    if (emojiInfo && emojiInfo.has_emojis && emojiInfo.detected.length > 0) {
        emojiRecognitionBar.classList.remove("hidden");
        emojiTags.innerHTML = "";
        for (const item of emojiInfo.detected) {
            const tag = document.createElement("span");
            tag.className = "emoji-tag";
            tag.innerHTML = `<strong>${item.emoji}</strong> ${item.name} (${Math.round(item.sarcasm_weight * 100)}% sarcasm bias)`;
            emojiTags.appendChild(tag);
        }
    } else {
        emojiRecognitionBar.classList.add("hidden");
    }

    // Vocal Pitch Track Canvas (Idea 2)
    if (data.pitch_contour && data.pitch_contour.length > 0) {
        const isFlat = conf ? conf.is_pitch_flat : (data.audio_analysis.pitch.label === "Flat");
        drawPitchContour(data.pitch_contour, isFlat);
    }

    // Acoustic Telemetry
    const a = data.audio_analysis;
    pitchBadge.textContent = a.pitch.label.toUpperCase();
    pitchValue.textContent = `${Math.round(a.pitch_mean_hz)} Hz`;
    pitchDetail.textContent = a.pitch.detail;

    energyBadge.textContent = a.energy.label.toUpperCase();
    energyValue.textContent = `${a.energy_rms.toFixed(3)} RMS`;
    energyDetail.textContent = a.energy.detail;

    paceBadge.textContent = a.pace.label.toUpperCase();
    tempoValue.textContent = `${Math.round(a.tempo_bpm)} BPM`;
    paceDetail.textContent = a.pace.detail;

    // Ablation Ensembles
    const comp = data.model_comparison;
    renderAblationRow(textMeter, textScore, textChip, comp.text_only);
    renderAblationRow(audioMeter, audioScore, audioChip, comp.audio_only);
    renderAblationRow(fusionMeter, fusionScore, fusionChip, comp.fusion);

    // Scroll to results
    resultsSection.scrollIntoView({ behavior: "smooth", block: "start" });
}

function renderAblationRow(meterEl, scoreEl, chipEl, modelData) {
    const isSarcastic = modelData.label === "SARCASTIC";

    setTimeout(() => {
        meterEl.style.width = `${modelData.sarcasm_probability}%`;
    }, 150);

    scoreEl.textContent = `${modelData.sarcasm_probability}%`;
    chipEl.textContent = modelData.label;
    chipEl.className = `verdict-chip ${isSarcastic ? "sarcastic" : "genuine"}`;
}

// ===== Re-evaluation (What-If Sandbox) =====
reevaluateBtn.addEventListener("click", async () => {
    const editedText = transcriptInput.value.trim();
    if (!editedText) return;

    loadingSection.classList.remove("hidden");
    resultsSection.classList.add("hidden");
    systemStatus.querySelector(".status-text").textContent = "RE-EVALUATING...";

    try {
        const resp = await fetch("/api/reevaluate", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ text: editedText }),
        });

        if (!resp.ok) {
            const err = await resp.json();
            throw new Error(err.error || "Re-evaluation error");
        }

        const data = await resp.json();
        renderAnalysis(data);

    } catch (err) {
        console.error("Re-evaluation error:", err);
        alert(`Re-evaluation Error: ${err.message}`);
    } finally {
        loadingSection.classList.add("hidden");
        systemStatus.querySelector(".status-text").textContent = "SYSTEM READY";
    }
});

// ===== Emoji Palette Insert =====
document.querySelectorAll(".emoji-insert-btn").forEach(btn => {
    btn.addEventListener("click", () => {
        const emoji = btn.dataset.emoji;
        transcriptInput.value += ` ${emoji}`;
        transcriptInput.focus();
    });
});

// ===== Benchmark Preset Handlers =====
document.querySelectorAll(".preset-chip").forEach(chip => {
    chip.addEventListener("click", async () => {
        const id = chip.dataset.id;
        loadingSection.classList.remove("hidden");
        resultsSection.classList.add("hidden");
        systemStatus.querySelector(".status-text").textContent = "FETCHING BENCHMARK...";

        try {
            const resp = await fetch(`/api/sample/${id}`);
            if (!resp.ok) {
                const err = await resp.json();
                throw new Error(err.error || "Failed to load benchmark");
            }
            const data = await resp.json();
            renderAnalysis(data);
        } catch (err) {
            console.error("Benchmark error:", err);
            alert(`Benchmark fault: ${err.message}`);
        } finally {
            loadingSection.classList.add("hidden");
            systemStatus.querySelector(".status-text").textContent = "SYSTEM READY";
        }
    });
});

// ===== File Upload Handler =====
fileUpload.addEventListener("change", (e) => {
    const file = e.target.files[0];
    if (file) {
        sendAudioForInference(file);
    }
});

// ===== Reset Action =====
resetBtn.addEventListener("click", () => {
    resultsSection.classList.add("hidden");
    textMeter.style.width = "0%";
    audioMeter.style.width = "0%";
    fusionMeter.style.width = "0%";
    conflictMeter.style.width = "0%";
    drawIdleGrid();
    drawIdlePitchGrid();
    window.scrollTo({ top: 0, behavior: "smooth" });
});

// ===== Record Button Event Listener =====
recordBtn.addEventListener("click", () => {
    if (isRecording) {
        stopRecording();
    } else {
        startRecording();
    }
});

// Window lifecycle
window.addEventListener("load", setupCanvases);
window.addEventListener("resize", setupCanvases);
